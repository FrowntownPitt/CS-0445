Austin Frownfelter - 4032386

NOTE: For running the test methods, the format of the input is:
java FriendsCoupon test
OTHERWISE:
java FriendsCoupon [filename] [max coupons]

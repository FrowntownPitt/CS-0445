Austin Frownfelter - 4032386
CS 0445 MoWe 6:00-7:15 ;; Wednesday Recitation

Bonus:
	Set.java implements a dynamic array, so it will never throw a SetFullException.  Default array size is 1, and resizing doubles size.

	Profile.java contains recommend() and it only returns a Profile which the user is not currently following, and is followed by one it follows (not friend, but friend-of-friend).
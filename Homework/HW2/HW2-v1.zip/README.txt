Austin Frownfelter - 4032386
CS 0445 MoWe 6:00-7:15 ;; Wednesday Recitation

Potential Issues/Incompletions:
	The errors caught are most likely not all that can be.  Currently caught errors are:
		- Invalid operator

Bonus:
	InfixEvaluator implements a function to handle variables.  It should handle multi-character, and multiple variables.
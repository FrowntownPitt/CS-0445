
package videoengine;

/**
 * A video in the video engine.
 */
public interface Video {

}

